package application;

import javafx.scene.control.Button;

public class BluePad extends SimonPad {

    public BluePad(Button button) {
        super(3, button, "-fx-background-color: blue;");
    }

    @Override
    public String getBrightStyle() {
        return "-fx-background-color: lightblue;";
    }

    @Override
    public int getMidiNote() {
        return 76;
    }
}